#!/usr/bin/env python3

from brain_games.games.brain__progression import br_progr


def main():
    br_progr()


if __name__ == "__main__":
    main()
