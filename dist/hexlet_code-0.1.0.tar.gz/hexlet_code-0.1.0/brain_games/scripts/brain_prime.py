#!/usr/bin/env python3

from brain_games.games.brain__prime import br_prime


def main():
    br_prime()


if __name__ == "__main__":
    main()
