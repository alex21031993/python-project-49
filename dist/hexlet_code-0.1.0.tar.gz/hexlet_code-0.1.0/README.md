### Hexlet tests and linter status:
[![Actions Status](https://github.com/alex21031993/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/alex21031993/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/6d5319da56091717a6f9/maintainability)](https://codeclimate.com/github/alex21031993/python-project-49/maintainability)

[![asciicast](https://asciinema.org/a/yqhRBAUxIdYi0AgO7AJVs0DIf.svg)](https://asciinema.org/a/yqhRBAUxIdYi0AgO7AJVs0DIf)

[![asciicast](https://asciinema.org/a/WHUKAf07LD7ypwiPp5iN4BkTa.svg)](https://asciinema.org/a/WHUKAf07LD7ypwiPp5iN4BkTa)

[![asciicast](https://asciinema.org/a/qipSYmW7NemSCFPoOBnrA7dmU.svg)](https://asciinema.org/a/qipSYmW7NemSCFPoOBnrA7dmU)

[![asciicast](https://asciinema.org/a/XepBwJSeVI6SxDgYBQeEmVKSq.svg)](https://asciinema.org/a/XepBwJSeVI6SxDgYBQeEmVKSq)

[![asciicast](https://asciinema.org/a/X93htUT2yfmlh6gpeBL8NAkY7.svg)](https://asciinema.org/a/X93htUT2yfmlh6gpeBL8NAkY7)

